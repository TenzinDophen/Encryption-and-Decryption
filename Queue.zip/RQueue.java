public class RQueue<T> implements CarlQueue<T>
{
    private T front;
    private RQueue<T> inside;//pointer to another queue
    private T rear;

//     This method is useful for us in testing your code. Do not modify it.
//     public void showImmediateContents() {
//         System.out.println("Front: " + front);
//         System.out.println("Inside: " + inside);
//         System.out.println("Rear: " + rear);
//        }

   // Add item to the queue
    public void enqueue(T item)
    {if (front == null) //front always gets filled
         front = item;
     else if (rear == null) 
         rear = item;
     else
         {
         T temp = rear; //temporary variable to store the string
         rear = item;   //last item addedto the rear
         if (inside == null){ 
            inside = new RQueue<T>(); //creates a new Queue to store the inside strings
         }
         inside.enqueue(temp);//calls recursively 
      } 
       
      
   }
 
    // Return next item to come out of queue, without changing it.
    // If the queue is empty, return null
     public T getFront()
   { if (front == null) 
         return null;
     else 
      return front;
      }
      
   // Remove the next item from the queue. If the queue is empty, return null.
    public  T dequeue()
    { T tem = front; //storing the string in the fornt in tem variable
      if (rear == null){ //checking if its the last item
         front = null; 
         }
      else if (inside == null){ 
         front = rear;
         rear = null; 
         }
         
    
    else{
      front = inside.dequeue(); 
      if (inside.getFront() == null){
         inside = null;
         }
      }
      return tem; //returning the string at the front
   } 
//     // Print the entire contents of the queue to the screen 
     public void display()
    { String s = "";
      while(front != null){
         s += dequeue()+ " ";
         }
      System.out.println(s);
    }
 public static void main(String[] args) {
      RQueue<String> rb = new RQueue<>();
      rb.enqueue("Jack");
      rb.enqueue("Rocky");
      rb.enqueue("Anna");
      rb.enqueue("Pitts");
      rb.enqueue("Ruth");
      //rb.showImmediateContents();
      rb.display(); 
}
}